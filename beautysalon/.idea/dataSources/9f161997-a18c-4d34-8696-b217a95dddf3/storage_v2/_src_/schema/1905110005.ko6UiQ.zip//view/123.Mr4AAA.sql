create view `123` as
select `1905110005`.`j`.`JNO` AS `JNO`, `1905110005`.`spj`.`SNO` AS `SNO`
from (`1905110005`.`j`
         join `1905110005`.`spj` on ((`1905110005`.`j`.`JNO` = `1905110005`.`spj`.`JNO`)));

-- comment on column `123`.JNO not supported: 工程项目代码

-- comment on column `123`.SNO not supported: 供应商代码

